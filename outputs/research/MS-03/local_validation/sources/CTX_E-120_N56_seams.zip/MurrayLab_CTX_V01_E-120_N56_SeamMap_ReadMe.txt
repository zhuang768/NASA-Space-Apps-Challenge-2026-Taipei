Murray Lab Global CTX Mosaic of Mars: Version 1.0 
Production Date: February 27, 2023

For updated information and publications, please visit:
http://murray-lab.caltech.edu/CTX/

### Quad: E-120_N56 ###

---------------------------

## MurrayLab_CTX_V01_E-120_N56_SeamMap.shp ##

The quad seam map. This is a vectorized polygon shapefile that maps which original CTX data file is represented in the blended image mosaic data. Data within 0.25° of the quad boundary on all sides could be data from a neighboring quad that was included during the tile-blending process. The attribute field “MOS_QUAD” identifies the quad that contributed the original data.

The seam map contains 55 attribute fields for each feature, 51 of which are directly inherited from the CTX instrument itself. Descriptions of each field can be found via the PDS (https://pds-imaging.jpl.nasa.gov/data/mro/mars_reconnaissance_orbiter/ctx/mrox_0001/index/index.lbl).

The four additional attributes that apply to the mosaic are:

MOS_QUAD: The original quad from which the pixels were derived. Each quad was blended with its neighboring quad, so data that was originally blended in an adjacent quad could be rendered within the outer 0.25° of this quad.

MOS_IMG: The original CTX image ID plus a two-digit suffix to differentiate portions of segmented data. CTX data that contained transmission gaps (labeled “ERROR” in the “DATA_QUALITY_DESC” field) were split into multiple segments during the mosaicking process, necessitating distinct identifying names (i.e. P20_008697_2074_XN_27N125W_02). Data that did not have transmission gaps (labeled “OK” in the “DATA_QUALITY_DESEC” field) have “_00” as the suffix.

SESE_LINK: Link to the Arizona State University School of Earth & Space Exploration (SESE) page for the original CTX data used in the mosaic.

PDS_IMG: Link to the Planetary Data System (PDS) raw IMG file for the original CTX data used in the mosaic.

The seam map is georeferenced and projected using the following parameters:

Projection: Equidistant Cylindrical
Center Longitude: 0°
Latitude Type: Planetocentric
Equatorial Radius: 3,396,190 m
Polar Radius: 3,376,200 m

Proj4 syntax: '+proj=eqc +lat_ts=0 +lat_0=0 +lon_0=0 +x_0=0 +y_0=0 +a=3396190 +b=3376200 +units=m +no_defs'

.prj file syntax: PROJCS["Mars_2015_Ocentric_Equirectangular_clon_0",GEOGCS["GCS_Mars_2015_Ocentric",DATUM["D_Mars_2015",SPHEROID["Mars_2015",3396190.0,169.894447223612]],PRIMEM["Reference Meridian",0.0],UNIT["Degree",0.0174532925199433]],PROJECTION["Plate_Carree"],PARAMETER["false_easting",0.0],PARAMETER["false_northing",0.0],PARAMETER["central_meridian",0.0],UNIT["Meter",1.0]]

The directory also contains the accompanying files that are linked to the .shp shapefile. These include MurrayLab_CTX_V01_SeamMap_E-120_N56.dbf, MurrayLab_CTX_V01_SeamMap_E-120_N56.shx and MurrayLab_CTX_V01_SeamMap_E-120_N56.prj. 

---------------------------

The Context Camera (CTX) was built by Malin Space Science Systems (https://www.msss.com/).
CTX is on board the Mars Reconnaissance Orbiter, which was built by the Jet Propulsion Laboratory for NASA.
The Murray Lab is a data visualization and analysis facility within the Division of Geological and Planetary Sciences at the California Institute of Technology (http://murray-lab.caltech.edu/).

The Global CTX Mosaic project was funded by the NASA Planetary Data Archiving, Restoration, and Tools (PDART) program.
